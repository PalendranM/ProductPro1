﻿namespace ProductPro.logging
{
    public interface ILogging
    {
        public void Log(string message,string type);
    }

}
